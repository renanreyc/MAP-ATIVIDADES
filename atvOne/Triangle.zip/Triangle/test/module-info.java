module Test {
	requires org.junit.jupiter.api;
}