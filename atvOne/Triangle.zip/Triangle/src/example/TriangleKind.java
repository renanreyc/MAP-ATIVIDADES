package example;

public enum TriangleKind {
    EQUILATERAL, 
    ISOSCELES, 
    SCALENE 
}