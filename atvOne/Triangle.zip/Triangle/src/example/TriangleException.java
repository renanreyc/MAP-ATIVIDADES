package example;

public class TriangleException extends Exception {
	 
    public TriangleException() { 
    } 
}
